use scott;
show tables;

-- 1. 부서위치가 CHICAGO인 모든 사원에 대해 이름,업무,급여 출력하는 SQL을 작성하세요.
select e.ename 이름 , e.job 업무 , e. sal 급여 from dept d inner join emp e
on d.deptno = e.deptno
where d.loc = 'CHICAGO';

-- 2. 부하직원이 없는 사원의 사원번호,이름,업무,부서번호 출력하는 SQL을 작성하세요.
select a.empno 사원번호, a.ename 이름, a.job 업무, a.deptno 부서번호 from emp a left outer join emp b
on a.empno = b.mgr
where b.mgr is null;

-- 3. BLAKE와 같은 상사를 가진 사원의 이름,업무,상사번호 출력하는 SQL을 작성하세요.
select ename 이름, job 업무, mgr 상사번호 from emp
where mgr = (
			select mgr 
			from emp 
            where ename = 'BLAKE'
            );

-- 4. 입사일이 가장 오래된 사람 5명을 검색하세요.
select * from emp 
order by hiredate
limit 5;

-- 5. JONES 의 부하 직원의 이름, 업무, 부서명을 검색하세요.
select a.ename 이름, a.job 업무, b.dname 부서명 from emp a inner join dept b
on a.deptno = b.deptno
where mgr = (
			select empno 
			from emp 
            where ename = 'JONES'
            );