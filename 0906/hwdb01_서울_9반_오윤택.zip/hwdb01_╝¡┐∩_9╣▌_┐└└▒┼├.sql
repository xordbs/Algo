DROP DATABASE IF EXISTS shop;

CREATE DATABASE shop;

USE shop;

create table product (
	pcode int(4) primary key,
    pname varchar(10),
    price int(10),
    quantity int(10)
    )ENGINE=InnoDB default CHARSET=utf8;
    
Insert into product values(0001, '삼성OLDETV', 2500000, 30);
Insert into product values(0002, '삼성비스포크', 3400000, 10);
Insert into product values(0003, '노트북', 2000000, 10);
Insert into product values(0004, 'TV', 200000, 20);
Insert into product values(0005, '전자렌지', 100000, 20);

select *, round(price*0.85,0) as'세일가' from product;

update product set price = price*1.2 where pname like'%TV%';

select sum(price) from product;