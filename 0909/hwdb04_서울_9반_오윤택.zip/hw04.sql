-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema shopdb
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema shopdb
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `shopdb` DEFAULT CHARACTER SET utf8 ;
USE `shopdb` ;

-- -----------------------------------------------------
-- Table `shopdb`.`user`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `shopdb`.`user` ;

CREATE TABLE IF NOT EXISTS `shopdb`.`user` (
  `user_id` INT NOT NULL AUTO_INCREMENT,
  `user_name` VARCHAR(20) NULL,
  `user_addr` VARCHAR(100) NULL,
  `user_tel1` VARCHAR(45) NULL,
  `user_tel2` VARCHAR(45) NULL,
  PRIMARY KEY (`user_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `shopdb`.`order`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `shopdb`.`order` ;

CREATE TABLE IF NOT EXISTS `shopdb`.`order` (
  `order_num` INT NOT NULL AUTO_INCREMENT,
  `order_total_price` INT NULL,
  `order_pay` TINYINT NULL,
  `order_post` TINYINT NULL,
  `user_id` INT NULL,
  `ordercol` VARCHAR(45) NULL,
  PRIMARY KEY (`order_num`),
  INDEX `order_user_fk_idx` (`user_id` ASC) VISIBLE,
  CONSTRAINT `order_user_fk`
    FOREIGN KEY (`user_id`)
    REFERENCES `shopdb`.`user` (`user_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `shopdb`.`product`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `shopdb`.`product` ;

CREATE TABLE IF NOT EXISTS `shopdb`.`product` (
  `product_code` INT NOT NULL,
  `product_name` VARCHAR(45) NULL,
  `product_price` INT NULL,
  `product_cnt` INT NULL,
  PRIMARY KEY (`product_code`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `shopdb`.`order_detail`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `shopdb`.`order_detail` ;

CREATE TABLE IF NOT EXISTS `shopdb`.`order_detail` (
  `detail_code` INT NOT NULL AUTO_INCREMENT,
  `order_num` INT NOT NULL,
  `product_code` INT NOT NULL,
  `order_cnt` INT NULL,
  PRIMARY KEY (`detail_code`),
  INDEX `detail_product_code_fk_idx` (`product_code` ASC) VISIBLE,
  INDEX `detail_order_num_fk_idx` (`order_num` ASC) VISIBLE,
  CONSTRAINT `detail_product_code_fk`
    FOREIGN KEY (`product_code`)
    REFERENCES `shopdb`.`product` (`product_code`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `detail_order_num_fk`
    FOREIGN KEY (`order_num`)
    REFERENCES `shopdb`.`order` (`order_num`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
