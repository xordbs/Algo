package IM대비;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Solution_SWEA_1979_어디에단어가들어갈수있을까_D2_오윤택 {
	static int TC;
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		TC = Integer.parseInt(br.readLine());
		
		for (int i = 1; i <= TC; i++) {
			StringTokenizer str = new StringTokenizer(br.readLine(), " ");
			int size = Integer.parseInt(str.nextToken());
			int value = Integer.parseInt(str.nextToken());
			int[][] map = new int[size][size];
			int cnt = 0;
			
			for (int a = 0; a < size; a++) {
				str = new StringTokenizer(br.readLine(), " ");
				for (int b = 0; b < size; b++) {
					map[a][b] = Integer.parseInt(str.nextToken());
				}
			} // 입력 끝
			
			for (int j = 0; j < size; j++) {
				// x축 계산
				int xCnt = 0;
				for (int j2 = 0; j2 < size; j2++) {
					if(map[j][j2] == 1) xCnt++;
					else {
						if(xCnt == value) cnt++;
						xCnt = 0;
					}
					if(j2 == size-1 && xCnt == value) cnt++; 
				}
				// y축 계산
				int yCnt = 0;
				for (int j2 = 0; j2 < size; j2++) {
					if(map[j2][j] == 1) yCnt++;
					else {
						if(yCnt == value) cnt++;
						yCnt = 0;
					}
					if(j2 == size-1 && yCnt == value) cnt++;
				}
			}
			System.out.println("#"+i+" "+cnt);
		}
	}
}


/*#1 2
#2 6
#3 6
#4 0
#5 14
#6 2
#7 45
#8 0
#9 98
#10 7*/


