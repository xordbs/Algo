package IM대비;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Solution_SWEA_1984_중간평균값구하기_D2_오윤택 {
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		
		for (int i = 1; i <= tc; i++) {
			int[] arr = new int[10];
			StringTokenizer str = new StringTokenizer(br.readLine(), " ");
			for (int j = 0; j < arr.length; j++) arr[j] = Integer.parseInt(str.nextToken());
			Arrays.sort(arr);
			int sum = 0;
			for (int j = 1; j < 9; j++) sum += arr[j];
			double value = (double)Math.round(sum/(8.0));
			System.out.println("#"+i+" "+(int)value);
		}
	}
}