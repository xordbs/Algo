package IM대비;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Stack;
import java.util.StringTokenizer;

public class Solution_SWEA_3499_퍼펙트셔플_D3_오윤택 {
	
	static int TC;
	
	public static void main(String[] args) throws Exception {
		BufferedReader sc = new BufferedReader(new InputStreamReader(System.in));
		TC = Integer.parseInt(sc.readLine());
		
		for (int i = 1; i <= TC; i++) {
			Stack<String> stack = new Stack<String>();
			Stack<String> stack2 = new Stack<String>();
			Stack<String> temp = new Stack<String>();
			StringBuilder sb = new StringBuilder();
			sb.append("#").append(i).append(" ");
			int n = Integer.parseInt(sc.readLine());
			int a= n/2, b = n/2;
			if(n%2 != 0) {
				a +=1;
			}
			StringTokenizer str = new StringTokenizer(sc.readLine()," ");
			for (int j = 0; j < a; j++) {
				stack.push(str.nextToken());
			}
			for (int j = 0; j < b; j++) {
				stack2.push(str.nextToken());
			}
			if(n%2 == 0) {
				for (int j = 0; j < b; j++) {
					if(!stack2.empty())
						temp.push(stack2.pop());
					if(!stack.empty())
						temp.push(stack.pop());
				}
			}else {
				for (int j = 0; j < a; j++) {
					if(!stack.empty())
						temp.push(stack.pop());
					if(!stack2.empty())
						temp.push(stack2.pop());
				}
			}
			for (int j = 0; j < n; j++) {
				sb.append(temp.pop()+" ");
			}
			sb.append("\n");
			System.out.print(sb);
		}
	}
}
