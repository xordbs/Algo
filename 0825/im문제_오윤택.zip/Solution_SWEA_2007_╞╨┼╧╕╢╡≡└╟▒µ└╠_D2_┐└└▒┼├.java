package IM대비;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Solution_SWEA_2007_패턴마디의길이_D2_오윤택 {
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int TC = Integer.parseInt(br.readLine());
		
		for (int i = 1; i <= TC; i++) {
			String str = br.readLine();
			int cnt = 0;
			for (int j = 1; j < 10; j++) {
				String a = str.substring(0,j);
				String b = str.substring(j,j+j);
				
				if(a.equals(b)) {
					cnt = j;
					break;
				}
			}
			System.out.println("#"+i+" "+cnt);
		}
	}
}
//#1 5
//#2 7
//#3 6
//#4 3
//#5 4
//#6 5
//#7 9
//#8 5
//#9 9
//#10 3