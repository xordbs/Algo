package IM대비;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Solution_SWEA_5356_의석이의세로로말해요_D3_오윤택 {
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int TC = Integer.parseInt(br.readLine());
		
		for (int i = 1; i <= TC; i++) {
			char[][] arr = new char[5][15];
			for (int j = 0; j < 5; j++) {
				String str = br.readLine();
				for (int k = 0; k < str.length(); k++) {
					arr[j][k] = str.charAt(k);
				}
			}
			StringBuilder sb = new StringBuilder();
			sb.append("#").append(i).append(" ");
			for (int j = 0; j < 15; j++) {
				for (int k = 0; k < 5; k++) {
					if(arr[k][j] != '\u0000') {
						sb.append(arr[k][j]);
					}
				}
			}
			System.out.println(sb);
		}
	}
	
}
