package IM대비;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Solution_SWEA_2805_농작물수확하기_오윤택 {

	public static void main(String[] args) throws Exception {

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		
		StringBuilder sb = new StringBuilder();
		
		for (int i = 1; i <= tc; i++) {
			int N = Integer.parseInt(br.readLine());
			int[][] map = new int[N][N];
			int sum = 0;
			
			for (int row = 0; row < N; row++) { // 배열 입력
				String str = br.readLine();
				for (int col = 0; col < N; col++) {
					map[row][col] = str.charAt(col)-'0';
				}
			}
			
			for (int a = 0; a < N; a++) { // 배열의 row 만큼 반복
				if(a <= (N/2)) { // 마름모의 중간까지
					for (int b = N/2-a; b < N-(N/2-a); b++) {
						sum += map[a][b];
					}
				}else { // 마름모의 중간보다 작은 경우
					for (int b = a-N/2; b < N-(a-N/2); b++) {
						sum += map[a][b];
					}
				}
			}
			
			sb.append("#").append(i).append(" ").append(sum).append("\n");
		}
		System.out.println(sb);
	}

}
