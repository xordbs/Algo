package IM대비;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Solution_SWEA_1961_숫자배열회전_D2_오윤택 {
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int TC = Integer.parseInt(br.readLine());
		for (int i = 1; i <= TC; i++) {
			int N  = Integer.parseInt(br.readLine());
			int[][] arr = new int[N][N];
			String[][] resultMap = new String[N][3];
			
			for (int j = 0; j < N; j++) {
				StringTokenizer str = new StringTokenizer(br.readLine()," ");
				for (int k = 0; k < N; k++) {
					arr[j][k] = Integer.parseInt(str.nextToken()); 
				}
			}
			for (int j = 0; j < resultMap.length; j++) {
				Arrays.fill(resultMap[j], "");
			}
			
			for (int j = 0; j < 3; j++) {
				for (int k = 0; k < N; k++) {
					if(j == 0) {
						for (int l = 0; l < N; l++) {
							resultMap[k][j] += Integer.toString(arr[N-(l+1)][k]);
						}
					}else if(j == 1) {
						for (int l = N-1; l >= 0; l--) {
							resultMap[k][j] += Integer.toString(arr[N-(k+1)][l]);
						}
					}else {
						for (int l = N-1; l >= 0; l--) {
							resultMap[k][j] += Integer.toString(arr[N-(l+1)][N-(k+1)]);
						}
					}
				}
			}
			System.out.println("#"+i);
			for (int j = 0; j < N; j++) {
				for (int j2 = 0; j2 < 3; j2++) {
					System.out.print(resultMap[j][j2]+" ");
				}
				System.out.println();
			}
		}
	}
}

/*
 #1
741 987 369 
852 654 258 
963 321 147 
#2
872686 679398 558496 
952899 979157 069877 
317594 487722 724799 
997427 894586 495713 
778960 562998 998259 
694855 507496 686278 
#3
0223319 0639550 5847800 
5851613 0762582 0170676 
5528111 8675252 5973763 
9255478 7035813 8745529 
3673795 4774163 1118255 
6760710 8197111 3161585 
0087485 5058139 9133220 
#4
876 218 432 
190 397 091 
234 406 678 
#5
958701 171819 123041 
176786 467775 814067 
873604 008368 048871 
178840 348677 406378 
760418 214080 687671 
140321 180461 107859 
#6
894 108 971 
091 799 190 
179 914 498 
#7
99451 66169 75356 
66720 58269 28286 
12842 32874 24821 
68282 58425 02766 
65357 72201 15499 
#8
344 693 336 
968 364 869 
633 384 443 
#9
404 344 733 
419 310 914 
337 794 404 
#10
76501 93107 15669 
01271 60916 43803 
19597 68525 79591 
30834 53970 17210 
96651 14711 10567 

 */
