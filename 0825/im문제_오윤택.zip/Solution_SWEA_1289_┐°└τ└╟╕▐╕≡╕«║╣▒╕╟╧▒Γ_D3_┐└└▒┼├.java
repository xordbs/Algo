package IM대비;

import java.util.Scanner;

public class Solution_SWEA_1289_원재의메모리복구하기_D3_오윤택 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
         
        int t = sc.nextInt();
         
        for (int i = 0; i < t; i++) {
            char[] bit = sc.next().toCharArray();
            char tmp = '0';
            int cnt = 0;
            for (int j = 0; j < bit.length; j++) {
                if(bit[j] != tmp) {
                    tmp = bit[j];
                    cnt++;
                }
            }
            System.out.println("#"+(i+1)+" "+cnt);
        }
        sc.close();
    }
}
