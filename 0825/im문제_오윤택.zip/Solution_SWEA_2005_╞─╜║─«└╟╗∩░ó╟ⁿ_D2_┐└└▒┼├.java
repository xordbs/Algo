package IM대비;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Solution_SWEA_2005_파스칼의삼각형_D2_오윤택 {
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int TC = Integer.parseInt(br.readLine());
		
		for (int i = 1; i <= TC; i++) {
			int N = Integer.parseInt(br.readLine());
			int[][] arr = new int[N][N];
			arr[0][0] = 1;
			
			for (int a = 1; a < N; a++) {
				for (int b = 0; b < N; b++) {
					if(b-1  >= 0) {
						arr[a][b] = arr[a-1][b-1] + arr[a-1][b];
					}else if(b-1  < 0){
						arr[a][b] = arr[a-1][b];
					}
				}
			}
			
			System.out.println("#"+i);
			for (int a = 0; a < arr.length; a++) {
				for (int b = 0; b < arr.length; b++) {
					if(arr[a][b] == 0) break;
					System.out.print(arr[a][b]+" ");
				}
				System.out.println();
			}
		}
	}
}
